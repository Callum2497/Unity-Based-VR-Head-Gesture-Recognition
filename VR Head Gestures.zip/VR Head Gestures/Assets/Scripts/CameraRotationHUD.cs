﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CameraRotationHUD : MonoBehaviour
{

    public Text cameraX;
    public Text cameraY;
    public Text cameraZ;


	// Use this for initialization
	void Start ()
    {

        CameraRotation();

	}
	
	// Update is called once per frame
	void Update ()
    {

        CameraRotation();

    }

    void CameraRotation()
    {

        cameraX.text = "Camera X = " + transform.rotation.eulerAngles.x;
        cameraY.text = "Camera Y = " + transform.rotation.eulerAngles.y;
        cameraZ.text = "Camera Z = " + transform.rotation.eulerAngles.z;

    }
}

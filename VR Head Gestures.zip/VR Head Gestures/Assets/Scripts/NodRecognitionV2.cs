﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NodRecognitionV2 : MonoBehaviour
{

    private Vector3[] angles;
    private int index;
    private Vector3 centreAngle;

    //public GameObject playerCapsule;
    public Camera mainCamera;
    public GameObject responsiveObject;

	// Use this for initialization
	void Start ()
    {

        ResetGesture();

	}
	
	// Update is called once per frame
	void Update ()
    {
		
        angles[index] = mainCamera.transform.eulerAngles;
        index++;

        if (index == 35) // 80
        {
            CheckMovement();
            ResetGesture();
        }

    }

    void CheckMovement() // Used to check the angles the headset goes to distinguish whether or not a gesture is made.
    {

        bool right = false, left = false, up = false, down = false; // All directions are started as false as to not cause a gesture to accidentally be made.

        for (int i = 0; i < 35; i++) // 80
        {

            if (angles[i].x < centreAngle.x - 7.5f && !up) // Originally 20.0f.
            {
                up = true;
            }

            else if (angles[i].x > centreAngle.x + 7.5f && !down) // Originally 20.0f.
            {
                down = true;
            }

            if (angles[i].y < centreAngle.y - 10.0f && !left) // Originally 20.0f.
            {
                left = true;
            }

            else if (angles[i].y > centreAngle.y + 10.0f && !right) // Originally 20.0f.
            {
                right = true;
            }

        }

        if (left && right && !(up && down))
        {
            // Player shook their head left and right (or vice versa) to indicate "No", which then turns the ball Red.
            print("Response = No");
            responsiveObject.GetComponent<Renderer>().material.color = Color.red;
        }

        if (up && down && !(left && right))
        {
            // Player's nod their head up and down (or vice versa) to gesture indicated "Yes", which then turns the ball Green.
            print("Response = Yes");
            responsiveObject.GetComponent<Renderer>().material.color = Color.green;
        }

    }

    void ResetGesture() // Used to reset the angle as to start the process of gesturing again.
    {

        angles = new Vector3[35]; // 80
        index = 0;
        centreAngle = mainCamera.transform.eulerAngles;

    }
}

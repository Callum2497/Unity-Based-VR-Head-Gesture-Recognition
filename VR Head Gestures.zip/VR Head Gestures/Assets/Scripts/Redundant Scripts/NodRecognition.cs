﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NodRecognition : MonoBehaviour
{

    private Vector3[] angles;
    //private Vector3 centreAngle;

    private float rotY = 0.0f; // rotation around the up/y axis
    private float rotX = 0.0f; // rotation around the right/x axis

    private float timer = 0;

    bool right = false, left = false, up = false, down = false;

    //private int index;
    public GameObject responsiveObject;
    public GameObject Capsule;

	// Use this for initialization
	void Start ()
    {

        Capsule = GameObject.FindGameObjectWithTag("Player");

        
        //ResetGesture();

    }
	
	// Update is called once per frame
	void Update ()
    {

        //angles[index] = Camera.main.transform.eulerAngles;
        //index++;

        //if (index == 80)
        //{

        Vector3 rot = Capsule.transform.eulerAngles;
        rotY = rot.y;
        rotX = rot.x;

            CheckMovement();
            //ResetGesture();

        //}
		
	}

    void CheckMovement()
    {

       

        //for (int i = 0; i < 80; i++)
        //{

            if (rotY > 20.0f)
            {

                up = true;
                Timer();

            }

            else if (rotY < -20.0f)
            {

                down = true;

            }

            if (rotX < -20.0f)
            {

                left = true;
                Timer();

            }

            else if (rotX > 20.0f)
            {

                right = true;

            }

            if (timer > 1000000)
            {
                timer = 0;

                up = false;
                down = false;
                left = false;
                right = false;

            }
            
        //}

        

    }

    void Timer()
    {

        if (timer == 0)
        {
            timer += Time.deltaTime;
        }

        else if (timer > 0 && timer <= 10000000)
        {
            if (left && right && !(up && down))
            {
                 // Player shook their head left and right to indicate "no".
                 print("Response = No");
                 responsiveObject.GetComponent<Renderer>().material.color = Color.red;

            }

            if (up && down && !(left && right))
            {
                 // Player shook their head up and down to indicate "yes".
                 print("Response = Yes");
                 responsiveObject.GetComponent<Renderer>().material.color = Color.green;

            }
        }

    }

    /*private void ResetGesture()
    {

        angles = new Vector3[80];
        index = 0;
        centreAngle = Camera.main.transform.eulerAngles;

    }*/
}

 /*if (angles[i].x > rotY + 20.0f && !up)
            {

                up = true;
                Timer();

            }

            else if (angles[i].x<rotY - 20.0f && !down)
            {

                down = true;

            }

            if (angles[i].y<rotX - 20.0f && !left)
            {

                left = true;
                Timer();

            }

            else if (angles[i].y<rotX + 20.0f && !right)
            {

                right = true;

            }

            if (timer > 1000000)
            {
                timer = 0;

                up = false;
                down = false;
                left = false;
                right = false;

            }*/